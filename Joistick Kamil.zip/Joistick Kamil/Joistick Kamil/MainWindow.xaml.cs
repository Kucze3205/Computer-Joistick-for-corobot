﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Joistick_Kamil
{
   
    public partial class MainWindow : Window
    {
        float change;

        float[] cord = new float[3];

        public MainWindow()
        {
            InitializeComponent();
            cord[0] = 0f;
            cord[1] = -0.662f;
            cord[2] = 0.01f; // base coords

        }
        void movement(float change, int coord_i, float x, float y, float z) // coord_i = which coord(x,y,z) is changing // change = change ratio
        {
            Int32 port = 30003; // robot port
            string hostname = "192.168.1.102"; // robot hostname
            TcpClient client = new TcpClient(hostname, port);
            NetworkStream stream = client.GetStream();

            string[] cnv_cord = new string[3];

            cord[0] = x;
            cord[1] = y;
            cord[2] = z;

            for (int i = 0; i < 3; i++)
            {             
                if (coord_i == i)
                    cord[i] += change;
                     
                cnv_cord[i] = cord[i].ToString().Replace(",", "."); 
            }

            string message = 
            "movel(p[" + cnv_cord[0] + ", " + cnv_cord[1] + ", " + cnv_cord[2] + ", 0.0, 3.14, 0.0], a=0.2, v=0.4)";


            Byte[] data = System.Text.Encoding.ASCII.GetBytes(message + '\n'); //converting string cod

            stream.Write(data, 0, data.Length);
            Console.WriteLine("Sent: {0}", message);

            stream.Close();
            client.Close();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            movement(change, 0, cord[0], cord[1], cord[2]);
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            movement(-change, 1, cord[0], cord[1], cord[2]);

        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            movement(change, 1, cord[0], cord[1], cord[2]);

        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            movement(-change, 0, cord[0], cord[1], cord[2]);
        }

        private void Button_Click_4(object sender, RoutedEventArgs e)
        {
            movement(change, 2, cord[0], cord[1], cord[2]);
        }

        private void Button_Click_5(object sender, RoutedEventArgs e)
        {
            movement(-change, 2, cord[0], cord[1], cord[2]);
        }

        private void Button_Click_Reset(object sender, RoutedEventArgs e)
        {
            movement(0f, 4, 0, -0.662f, 0.01f);
        }

        
        private void Text_Change(object sender, TextChangedEventArgs e)
        {
            int text;
            text = Convert.ToInt32(textBox1.Text);

            if (text > 50)
            {

            }
            else
                change = text * 0.001f; // max change = 50
        }

        private void Button_Click_6(object sender, RoutedEventArgs e)
        {
            if(CheckBox1.IsChecked == true)
            {
                movement(0, 0, 0.001f * Convert.ToInt32(textBox2.Text), 0.001f * Convert.ToInt32(textBox3.Text), 0.001f * Convert.ToInt32(textBox4.Text)); // manual positioning
            }
        }




    }
}
